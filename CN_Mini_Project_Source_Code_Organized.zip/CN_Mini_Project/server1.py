import json
import os
import socket
import threading
import time

HOST = "0.0.0.0"
PORT = 5000
BUFFER_SIZE = 4096
MAX_HEADER_SIZE = 4096
MAX_FILE_SIZE = 100 * 1024 * 1024

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FILES_DIR = os.path.join(BASE_DIR, "files")
METADATA_PATH = os.path.join(BASE_DIR, "file_metadata.json")
os.makedirs(FILES_DIR, exist_ok=True)

USERS = {"prasanna@300": "prasanna@300"}

metadata_lock = threading.Lock()
metadata = {}


def load_metadata():
    global metadata
    try:
        with open(METADATA_PATH, "r", encoding="utf-8") as file:
            loaded = json.load(file)
        metadata = loaded if isinstance(loaded, dict) else {}
    except (OSError, json.JSONDecodeError):
        metadata = {}


def save_metadata():
    temporary = METADATA_PATH + ".tmp"
    with open(temporary, "w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)
    os.replace(temporary, METADATA_PATH)


def send_message(client_socket, message):
    client_socket.sendall((message + "\n").encode("utf-8"))


def receive_header(reader):
    line = reader.readline(MAX_HEADER_SIZE + 1)
    if not line:
        raise ConnectionError("Peer disconnected.")
    if len(line) > MAX_HEADER_SIZE or not line.endswith(b"\n"):
        raise ValueError("Invalid or oversized header.")
    return line[:-1].decode("utf-8").rstrip("\r")


def receive_exactly(reader, size, destination=None):
    remaining = size
    while remaining > 0:
        chunk = reader.read(min(BUFFER_SIZE, remaining))
        if not chunk:
            raise ConnectionError("File transfer was interrupted.")
        if destination is not None:
            destination.write(chunk)
        remaining -= len(chunk)


def get_safe_path(filename):
    if (
        not filename or filename in (".", "..")
        or "/" in filename or "\\" in filename
        or "\x00" in filename or "\n" in filename
        or "\r" in filename
        or os.path.basename(filename) != filename
    ):
        raise ValueError("Invalid filename.")

    filepath = os.path.join(FILES_DIR, filename)
    resolved_folder = os.path.realpath(FILES_DIR)
    resolved_path = os.path.realpath(filepath)

    if os.path.commonpath([resolved_folder, resolved_path]) != resolved_folder:
        raise ValueError("Access outside the shared folder is forbidden.")

    if os.path.islink(filepath):
        raise ValueError("Symbolic links are not allowed.")

    return filepath


def authenticate(reader, client_socket):
    line = receive_header(reader)
    parts = line.split(" ", 2)

    if len(parts) != 3 or parts[0].upper() != "AUTH":
        send_message(client_socket, "ERR Authentication required.")
        return False

    username, password = parts[1], parts[2]

    if USERS.get(username) != password:
        send_message(client_socket, "ERR Invalid username or password.")
        print("Authentication failed for user:", username)
        return False

    send_message(client_socket, "OK Authenticated.")
    print("Authenticated user:", username)
    return True


def handle_list(client_socket):
    rows = []

    with metadata_lock:
        for filename in sorted(os.listdir(FILES_DIR)):
            filepath = os.path.join(FILES_DIR, filename)

            if not os.path.isfile(filepath) or os.path.islink(filepath):
                continue

            if "\n" in filename or "\r" in filename:
                continue

            try:
                size = os.path.getsize(filepath)
            except OSError:
                continue

            info = metadata.get(filename, {})
            uploaded = info.get(
                "uploaded_at", "Unknown (existing file)"
            )

            rows.append(
                f"{filename} | {size} bytes | uploaded: {uploaded}"
            )

    send_message(client_socket, "OK " + str(len(rows)))

    for row in rows:
        send_message(client_socket, row)

    print(f"LIST completed: {len(rows)} file(s)")


def handle_download(client_socket, filename):
    filepath = get_safe_path(filename)

    if not os.path.isfile(filepath):
        send_message(client_socket, "ERR File not found.")
        return

    with open(filepath, "rb") as file:
        size = os.fstat(file.fileno()).st_size
        started = time.perf_counter()

        send_message(client_socket, "OK " + str(size))

        while True:
            chunk = file.read(BUFFER_SIZE)
            if not chunk:
                break
            client_socket.sendall(chunk)

        elapsed = max(time.perf_counter() - started, 1e-9)

    rate = size / elapsed / (1024 * 1024)

    print(
        f"DOWNLOAD completed: {filename}, {size} bytes, "
        f"{elapsed:.3f} s, {rate:.2f} MiB/s"
    )


def handle_upload(client_socket, reader, filename, size):
    if size < 0 or size > MAX_FILE_SIZE:
        send_message(client_socket, "ERR Invalid file size.")
        return

    filepath = get_safe_path(filename)
    temporary_path = filepath + ".uploading"

    if os.path.exists(filepath):
        send_message(client_socket, "ERR File already exists.")
        return

    started = time.perf_counter()

    try:
        with open(temporary_path, "xb") as output_file:
            receive_exactly(reader, size, output_file)

        if os.path.exists(filepath):
            os.remove(temporary_path)
            send_message(client_socket, "ERR File already exists.")
            return

        os.replace(temporary_path, filepath)

    except FileExistsError:
        send_message(
            client_socket,
            "ERR Another upload with this name is in progress."
        )
        return

    except Exception:
        try:
            os.remove(temporary_path)
        except OSError:
            pass
        raise

    elapsed = max(time.perf_counter() - started, 1e-9)
    rate = size / elapsed / (1024 * 1024)
    uploaded_at = time.strftime("%Y-%m-%d %H:%M:%S")

    with metadata_lock:
        metadata[filename] = {
            "size_bytes": size,
            "uploaded_at": uploaded_at
        }
        save_metadata()

    send_message(client_socket, "OK Upload completed.")

    print(
        f"UPLOAD completed: {filename}, {size} bytes, "
        f"{elapsed:.3f} s, {rate:.2f} MiB/s"
    )


def handle_client(client_socket, client_address):
    print("Client connected:", client_address)

    try:
        with client_socket.makefile("rb") as reader:
            if not authenticate(reader, client_socket):
                return

            command_line = receive_header(reader)
            parts = command_line.split(" ", 2)
            command = parts[0].upper()

            if command == "LIST" and len(parts) == 1:
                handle_list(client_socket)

            elif command == "DOWNLOAD" and len(parts) == 2:
                handle_download(client_socket, parts[1])

            elif command == "UPLOAD" and len(parts) == 3:
                try:
                    size = int(parts[2])
                except ValueError:
                    send_message(
                        client_socket, "ERR Invalid file size."
                    )
                    return

                handle_upload(
                    client_socket, reader, parts[1], size
                )

            else:
                send_message(
                    client_socket,
                    "ERR Invalid command or arguments."
                )

    except (ValueError, UnicodeDecodeError) as error:
        try:
            send_message(client_socket, "ERR " + str(error))
        except OSError:
            pass
        print("Invalid request:", error)

    except (ConnectionError, OSError) as error:
        print("Connection error:", error)

    except Exception as error:
        print("Unexpected error:", error)

    finally:
        client_socket.close()
        print("Client disconnected:", client_address)


def start_server():
    load_metadata()

    server_socket = socket.socket(
        socket.AF_INET, socket.SOCK_STREAM
    )
    server_socket.setsockopt(
        socket.SOL_SOCKET, socket.SO_REUSEADDR, 1
    )

    try:
        server_socket.bind((HOST, PORT))
        server_socket.listen()

        print("Concurrent File Sharing System")
        print("Server listening on", HOST, "port", PORT)
        print("Shared folder:", FILES_DIR)
        print("Metadata file:", METADATA_PATH)
        print("Demo username: prasanna@300")
        print("Demo password: prasanna@300")
        print("Waiting for clients...")

        while True:
            client_socket, client_address = server_socket.accept()

            threading.Thread(
                target=handle_client,
                args=(client_socket, client_address),
                daemon=True
            ).start()

    except KeyboardInterrupt:
        print("\nServer shutting down.")

    except OSError as error:
        print("Server error:", error)

    finally:
        server_socket.close()


if __name__ == "__main__":
    start_server()