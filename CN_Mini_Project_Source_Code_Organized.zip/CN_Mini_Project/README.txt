CONCURRENT FILE SHARING USING TCP SOCKETS WITH MININET AND SDN
===============================================================

Contents
--------
server1.py       TCP file server
client_h2.py     H2 client
client_h3.py     H3 client
sdn_controller.py  OpenFlow 1.3 learning-switch controller
file_metadata.json  File metadata
files/           Sample files shared by the server, including test20MB.bin
requirements.txt Python package dependency

Environment used in the project
--------------------------------
Ubuntu 26.04.1 LTS, Python 3.14.4, Mininet, Open vSwitch 3.7.1,
and OS-Ken 3.1.1.

Run order
---------
1. Start the SDN controller in Terminal 1, from this project directory:
     source ~/osken-legacy-env/bin/activate
     osken-manager sdn_controller.py

2. Start Mininet in Terminal 2:
     sudo mn -c
     sudo mn --topo single,3 --switch ovs,protocols=OpenFlow13 --controller remote,ip=127.0.0.1,port=6633

3. At the Mininet prompt, check connectivity:
     pingall

4. Start the TCP server inside H1. Keep it running:
     h1 python3 /media/sf_CN_MINI_PROJECT/server1.py

5. Start the H2 and H3 clients inside their respective Mininet hosts:
     h2 python3 /media/sf_CN_MINI_PROJECT/client_h2.py
     h3 python3 /media/sf_CN_MINI_PROJECT/client_h3.py

   The server and interactive clients each occupy the terminal while running.
   Use separate Mininet host terminals (for example, xterm h1, xterm h2, xterm h3
   if xterm is installed) when you need them to run at the same time.
   The client download directories are configured in the source code as:
     /media/sf_CN_MINI_PROJECT/h2_downloads
     /media/sf_CN_MINI_PROJECT/h3_downloads

6. Inspect OpenFlow rules from the Mininet prompt:
     sh ovs-ofctl -O OpenFlow13 dump-flows s1

7. Optional throughput test (iperf3 must be installed):
     h1 iperf3 -s -D
     h2 iperf3 -c 10.0.0.1 -t 10
     h3 iperf3 -c 10.0.0.1 -t 10

Important notes
---------------
- The server and clients currently use /media/sf_CN_MINI_PROJECT paths. If you
  extract the project elsewhere, update those paths in client_h2.py and
  client_h3.py, and use the extracted path when starting server1.py.
- The server source currently contains a hard-coded demo username/password.
  Change it before sharing this project publicly or deploying it beyond a
  controlled classroom demonstration.
- This archive contains source files and the server's sample files. It omits
  cached Python bytecode, duplicate/backup files, previous client downloads,
  and unrelated files from the original working directory.
- This package is organized from the ZIP supplied by the project team. The
  code has not been independently tested as part of creating this archive.
