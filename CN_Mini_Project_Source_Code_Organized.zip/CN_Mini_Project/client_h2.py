
import os
import socket
import time
import getpass

HOST = "10.0.0.1"
PORT = 5000
BUFFER_SIZE = 4096
MAX_HEADER_SIZE = 4096
MAX_FILE_SIZE = 100 * 1024 * 1024
MAX_LOGIN_ATTEMPTS = 3

BASE_DIR = "/media/sf_CN_MINI_PROJECT/h2_downloads"


def receive_header(reader):
    line = reader.readline(MAX_HEADER_SIZE + 1)

    if not line:
        raise ConnectionError("Server disconnected.")

    if len(line) > MAX_HEADER_SIZE or not line.endswith(b"\n"):
        raise ValueError("Invalid server response.")

    return line[:-1].decode("utf-8").rstrip("\r")


def receive_exactly(reader, size, destination):
    remaining = size

    while remaining > 0:
        chunk = reader.read(min(BUFFER_SIZE, remaining))

        if not chunk:
            raise ConnectionError("Transfer interrupted by server.")

        destination.write(chunk)
        remaining -= len(chunk)


def login_to_server(username, password):
    """Verify credentials with the server before showing the menu."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.settimeout(15)
        client.connect((HOST, PORT))

        with client.makefile("rb") as reader:
            client.sendall(
                f"AUTH {username} {password}\n".encode("utf-8")
            )

            response = receive_header(reader)

            if not response.startswith("OK "):
                raise PermissionError(response)

            return True


def connect_and_authenticate(username, password):
    """Create a new connection and authenticate it."""
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.settimeout(30)

    try:
        client.connect((HOST, PORT))
        reader = client.makefile("rb")

        client.sendall(
            f"AUTH {username} {password}\n".encode("utf-8")
        )

        response = receive_header(reader)

        if not response.startswith("OK "):
            reader.close()
            client.close()
            raise PermissionError(response)

        return client, reader

    except Exception:
        client.close()
        raise


def list_files(username, password):
    client, reader = connect_and_authenticate(username, password)

    try:
        client.sendall(b"LIST\n")
        response = receive_header(reader)

        if not response.startswith("OK "):
            print("Server error:", response)
            return

        count = int(response.split(" ", 1)[1])

        print("\n--- Files on server ---")

        if count == 0:
            print("No files available.")
            return

        for _ in range(count):
            print(receive_header(reader))

    finally:
        reader.close()
        client.close()


def download_file(username, password):
    filename = input("Enter filename to download: ").strip()

    if (
        not filename
        or filename in (".", "..")
        or "/" in filename
        or "\\" in filename
        or any(ch.isspace() for ch in filename)
    ):
        print("Invalid filename. Use a name without spaces or folders.")
        return

    output_path = os.path.join(BASE_DIR, filename)

    if os.path.exists(output_path):
        print("A file with that name already exists in this folder.")
        print("Rename or move the existing file first.")
        return

    client, reader = connect_and_authenticate(username, password)

    try:
        client.sendall(f"DOWNLOAD {filename}\n".encode("utf-8"))
        response = receive_header(reader)

        if not response.startswith("OK "):
            print("Download failed:", response)
            return

        size = int(response.split(" ", 1)[1])

        if size < 0 or size > MAX_FILE_SIZE:
            raise ValueError("Invalid file size received from server.")

        started = time.perf_counter()

        try:
            with open(output_path, "xb") as output_file:
                receive_exactly(reader, size, output_file)
        except Exception:
            if os.path.exists(output_path):
                os.remove(output_path)
            raise

        elapsed = max(time.perf_counter() - started, 0.000001)
        speed = size / elapsed / (1024 * 1024)

        print("Download successful:", output_path)
        print("File size:", size, "bytes")
        print(f"Time taken: {elapsed:.2f} seconds")
        print(f"Average speed: {speed:.2f} MiB/s")

    finally:
        reader.close()
        client.close()


def upload_file(username, password):
    filepath = input("Enter full path of the file to upload: ").strip()
    filepath = filepath.strip('"')

    if not os.path.isfile(filepath):
        print("Error: File does not exist.")
        return

    filename = os.path.basename(filepath)

    if (
        not filename
        or any(ch.isspace() for ch in filename)
        or "\n" in filename
        or "\r" in filename
    ):
        print("Please use a filename without spaces.")
        return

    size = os.path.getsize(filepath)

    if size > MAX_FILE_SIZE:
        print("Error: Maximum file size is 100 MB.")
        return

    client, reader = connect_and_authenticate(username, password)

    try:
        client.sendall(
            f"UPLOAD {filename} {size}\n".encode("utf-8")
        )

        started = time.perf_counter()

        with open(filepath, "rb") as source:
            while True:
                chunk = source.read(BUFFER_SIZE)

                if not chunk:
                    break

                client.sendall(chunk)

        response = receive_header(reader)
        elapsed = max(time.perf_counter() - started, 0.000001)

        if response.startswith("OK "):
            speed = size / elapsed / (1024 * 1024)
            print("Upload successful!")
            print("File size:", size, "bytes")
            print(f"Time taken: {elapsed:.2f} seconds")
            print(f"Average speed: {speed:.2f} MiB/s")
        else:
            print("Upload failed:", response)

    finally:
        reader.close()
        client.close()


def main():
    print("=" * 40)
    print("  CONCURRENT FILE SHARING SYSTEM")
    print("=" * 40)
    print("Please log in to access file sharing.\n")

    username = ""
    password = ""
    authenticated = False

    for attempt in range(1, MAX_LOGIN_ATTEMPTS + 1):
        try:
            username = input("Username: ").strip()

            # Visible password input works in terminals that do not
            # support hidden password input properly.
            password = input("Password (visible while typing): ")

            if not username or not password:
                print("Username and password cannot be empty.\n")
                continue

            print("\nChecking login...")

            login_to_server(username, password)
            authenticated = True
            print("Login successful! Welcome.\n")
            break

        except PermissionError:
            print("Incorrect username or password.\n")

        except (OSError, ConnectionError, ValueError) as error:
            print("Could not connect or log in:", error)
            print("Check that the server is running and try again.\n")

        if attempt < MAX_LOGIN_ATTEMPTS:
            print(f"Login attempts remaining: {MAX_LOGIN_ATTEMPTS - attempt}\n")

    if not authenticated:
        print("Login failed. Access denied. Closing client.")
        return

    while True:
        print("\n========== FILE SHARING MENU ==========")
        print("1. List files")
        print("2. Download a file")
        print("3. Upload a file")
        print("4. Logout and exit")
        print("=======================================")

        choice = input("Enter your choice: ").strip()

        try:
            if choice == "1":
                list_files(username, password)

            elif choice == "2":
                download_file(username, password)

            elif choice == "3":
                upload_file(username, password)

            elif choice == "4":
                print("Logged out. Goodbye!")
                break

            else:
                print("Invalid choice. Enter 1, 2, 3, or 4.")

        except PermissionError:
            print("Authentication rejected by server. Please restart the client.")

        except (OSError, ConnectionError, ValueError) as error:
            print("Operation failed:", error)

        except KeyboardInterrupt:
            print("\nOperation interrupted.")

        except Exception as error:
            print("Unexpected error:", error)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nClient closed by user.")
    except Exception as error:
        print("Client error:", error)

